# BaZi App - Credentials & Secrets

⚠️ **KEEP THIS FILE SECURE - DO NOT COMMIT TO GIT** ⚠️

---

## Bazi App Server (10.0.1.76)

### SSH Access
- **User**: nazmin
- **Host**: 10.0.1.76
- **Command**: `ssh nazmin@10.0.1.76`

### PostgreSQL Database
- **Host**: localhost
- **Port**: 5432
- **Database**: bazidb
- **User**: baziuser
- **Password**: `BaziPass2026`
- **Connection URL**: `postgresql://baziuser:BaziPass2026@localhost:5432/bazidb`

---

## AI Server (10.0.1.147)

### Ollama
- **Host**: 10.0.1.147
- **Port**: 11434
- **URL**: `http://10.0.1.147:11434`
- **Model**: llama3:latest

---

## JWT Authentication
- **Secret Key**: `bazi-mobile-app-jwt-secret-key-256ai-prod-2026`

---

## AdMob (Google)

### iOS (Production)
- **App ID**: `ca-app-pub-5491037392330095~5450979012`
- **Banner ID**: `ca-app-pub-5491037392330095/3367741151`
- **Interstitial ID**: `ca-app-pub-5491037392330095/2681345448`

### Android (Test - Replace for Production)
- **App ID**: `ca-app-pub-3940256099942544~3347511713`
- **Banner ID**: TBD
- **Interstitial ID**: TBD

---

## Domain & DNS
- **Domain**: 256ai.xyz
- **Provider**: Cloudflare
- **Status**: Complete

---

## Apple Developer
- **Account**: tigerrook65@gmail.com - Personal 
- **Team ID**: TBD

---

## Google Play Console
- **Account**: TBD

---

## OpenAI (Optional Fallback)
- **API Key**: `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`

---

## .env File Contents (for server)

```
DATABASE_URL=postgresql://baziuser:BaziPass2026@localhost:5432/bazidb
OLLAMA_HOST=http://10.0.1.147:11434
JWT_SECRET_KEY=bazi-mobile-app-jwt-secret-key-256ai-prod-2026
```

---

Last Updated: 2026-01-19
