# Claude Sync File - BaZi App Development

> **Last Updated:** 2026-01-24
> **Purpose:** Keep Windows Claude (backend) and Mac Claude (mobile app) in sync

---

## Current System Status

### Backend (Linux 10.0.1.76) - WORKING
- **Service:** bazi-app.service (uvicorn with 4 workers)
- **API Base:** https://256ai.xyz
- **Ollama:** http://10.0.1.147:11434 (llama3 model)

| Endpoint | Status | Notes |
|----------|--------|-------|
| GET / | ✅ Working | Health check |
| GET /weekly/{user_id} | ✅ Working | AI-generated weekly forecast |
| GET /monthly/{user_id} | ✅ Working | AI-generated monthly forecast |
| GET /yearly/{user_id} | ✅ Working | AI-generated yearly forecast |

### Mobile App (React Native) - ✅ ALL WORKING
- **Location:** ~/BaziMobileApp (on Mac - home directory, NOT Documents)
- **Build:** Xcode

| Screen | Status | Notes |
|--------|--------|-------|
| Weekly Forecast | ✅ Working | With ad wall |
| Monthly Forecast | ✅ Working | With ad wall |
| Yearly Forecast | ✅ Working | With ad wall (simplified screen) |

---

## Recent Changes (2026-01-23)

### Backend Changes
1. **Advisory Locking** - Added PostgreSQL advisory locks to prevent race conditions
   - Yearly: lock_id = user_id + 1,000,000
   - Monthly: lock_id = user_id + 2,000,000
   - File: `/home/nazmin/AstrologyApp/app.py`

2. **Ollama Client Timeout** - 120 second timeout on AI generation
   - File: `/home/nazmin/AstrologyApp/agents/narrative_agent.py`

3. **Multiple Workers** - uvicorn now runs with 4 workers
   - File: `/etc/systemd/system/bazi-app.service`

4. **[your name] Placeholder Fix** - Added post-processing to replace AI-generated placeholders
   - Function: `replace_name_placeholders()` replaces `[your name]`, `[Your Name]`, etc. with actual user name
   - Files: `/home/nazmin/AstrologyApp/agents/narrative_agent.py`, `app.py`, `tasks/scheduler.py`
   - Applied to: Weekly, Monthly, and Yearly readings
   - Note: Deleted cached yearly reading for user 3 (yvette) so new one generates with fix

### Mobile App Changes
1. **Null Safety in forecasts.ts**
   - All parsing functions now handle null/undefined content
   - API functions wrapped in try-catch with mock data fallback
   - File: `src/api/forecasts.ts`

2. **Defensive Rendering in YearlyForecastScreen.tsx**
   - Added conditional rendering for all array maps
   - Added fallback values for month properties
   - File: `src/screens/readings/YearlyForecastScreen.tsx`

---

## Completed Tasks (2026-01-24)

### Mac Claude (Mobile App) - ✅ ALL DONE
- [x] Verify yearly forecast screen loads without crashing
- [x] Test all three forecasts (weekly, monthly, yearly) display AI content
- [x] Check that ads display correctly (ad walls on all 3 screens)

### Windows Claude (Backend) - ✅ ALL DONE
- [x] Advisory locks working (no duplicate key errors)
- [x] [your name] placeholder fix deployed
- [x] Service restarted and verified

## Pending Tasks

### For Both
- [ ] Prepare for App Store submission
- [ ] Test placeholder fix on yvette's yearly reading (should regenerate with her name)

---

## API Response Formats

### Weekly Response
```json
{
  "user_id": 1,
  "user_name": "Test User",
  "week_start": "2026-01-19",
  "week_end": "2026-01-25",
  "content": "AI generated weekly reading...",
  "language": "en",
  "llm_provider": "ollama",
  "generated_at": "2026-01-23T..."
}
```

### Monthly Response
```json
{
  "user_id": 1,
  "user_name": "Test User",
  "month_start": "2026-01-01",
  "month_end": "2026-01-31",
  "month_name": "January",
  "year": 2026,
  "content": "AI generated monthly reading...",
  "language": "en",
  "llm_provider": "ollama",
  "generated_at": "2026-01-23T..."
}
```

### Yearly Response
```json
{
  "user_id": 1,
  "user_name": "Test User",
  "year": 2026,
  "content": "AI generated yearly reading...",
  "language": "en",
  "llm_provider": "ollama",
  "generated_at": "2026-01-23T..."
}
```

---

## Known Issues & Solutions

### Issue: Yearly forecast crashes app
**Cause:** Arrays (yearlyThemes, monthlyOutlook) could be undefined
**Solution:** Added conditional rendering `{array && array.length > 0 && ...}`

### Issue: Race condition with multiple users
**Cause:** Two requests could try to generate same reading simultaneously
**Solution:** PostgreSQL advisory locks before generation

### Issue: Server hangs during AI generation
**Cause:** Single uvicorn worker blocked during 60s+ Ollama call
**Solution:** 4 uvicorn workers + 120s timeout on Ollama client

### Issue: "[your name]" placeholder in AI output
**Cause:** Ollama/llama3 generates sign-offs like "Warm regards, [your name]" as a letter template
**Solution:** Added `replace_name_placeholders()` function that post-processes AI output to replace common placeholder patterns with the actual user name

---

## Quick Commands

### Backend (Windows Claude runs via SSH)
```bash
# Check service status
ssh nazmin@10.0.1.76 "systemctl status bazi-app"

# View logs
ssh nazmin@10.0.1.76 "journalctl -u bazi-app -n 50"

# Test endpoint
ssh nazmin@10.0.1.76 "curl -s http://localhost:8000/yearly/1 | head -c 500"

# Restart service (needs sudo or pkill)
ssh nazmin@10.0.1.76 "pkill -f uvicorn"
```

### Mobile App (Mac Claude)
```bash
# Navigate to project (HOME directory, not Documents!)
cd ~/BaziMobileApp

# Install pods
cd ios && pod install && cd ..

# Open Xcode
open ios/BaziMobileApp.xcworkspace

# Build: Cmd+Shift+K (clean), Cmd+R (run)
```

---

## Communication Protocol

When one Claude makes changes that affect the other:

1. **Update this file** with what changed
2. **Note the file paths** that were modified
3. **Include test commands** to verify the change
4. **Mark status** as pending/working/broken

---

## Contact Points

| System | IP | Access |
|--------|-----|--------|
| Backend Server | 10.0.1.76 | SSH as nazmin |
| Mac Build Machine | 10.0.0.143 | SSH as "mark lombardi" |
| Ollama AI Server | 10.0.1.147 | HTTP port 11434 |
| Public API | 256ai.xyz | HTTPS |
